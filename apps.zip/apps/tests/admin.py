from django.contrib import admin
from .models import Section, Test, Question, Answer, UserTestResult, SpeakingResult, UserProgress, DailyPlan

@admin.register(Section)
class SectionAdmin(admin.ModelAdmin):
    list_display = ('name', 'description')

@admin.register(Test)
class TestAdmin(admin.ModelAdmin):
    list_display = ('title', 'section', 'duration_minutes', 'is_active', 'created_at')
    list_filter = ('section', 'is_active')

@admin.register(Question)
class QuestionAdmin(admin.ModelAdmin):
    list_display = ('text', 'test', 'question_type', 'order')
    list_filter = ('question_type',)

@admin.register(Answer)
class AnswerAdmin(admin.ModelAdmin):
    list_display = ('text', 'question', 'is_correct')
    list_filter = ('is_correct',)

@admin.register(UserTestResult)
class UserTestResultAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'test', 'band_score', 'created_at')

@admin.register(SpeakingResult)
class SpeakingResultAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'test', 'band_score', 'created_at')

@admin.register(UserProgress)
class UserProgressAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'section', 'average_band_score', 'total_tests_taken', 'last_updated')

@admin.register(DailyPlan)
class DailyPlanAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'date', 'ai_generated', 'created_at')